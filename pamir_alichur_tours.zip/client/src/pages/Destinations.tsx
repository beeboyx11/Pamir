import Navigation from '@/components/Navigation';
import Carousel from '@/components/Carousel';
import { Mountain, Building2, Leaf, MapPin } from 'lucide-react';

interface Destination {
  name: string;
  description: string;
  activities: string[];
  images: string[];
  icons: { label: string; icon: React.ReactNode }[];
}

const destinations: { [key: string]: Destination[] } = {
  north: [
    {
      name: 'Fann Mountains',
      description: 'A stunning range featuring pristine alpine lakes, dramatic peaks, and verdant valleys. The Fann Mountains offer some of Central Asia\'s most accessible high-altitude trekking.',
      activities: ['Trekking', 'Lake hiking', 'Mountain photography', 'Alpine camping'],
      images: [
        'https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/content_fan_mountain_s_12a3f464.jpg',
        'https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/photo_2025-04-21_10-55-40_7a4c1508.jpg',
      ],
      icons: [
        { label: 'Adventure', icon: <Mountain size={24} /> },
        { label: 'Nature', icon: <Leaf size={24} /> },
      ],
    },
    {
      name: 'Khujand',
      description: 'An ancient Silk Road city with a rich history spanning over 2,500 years. Khujand blends historical architecture with vibrant bazaars and cultural heritage.',
      activities: ['City tours', 'Bazaar exploration', 'Historical sites', 'Local cuisine'],
      images: [
        'https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/photo_2025-04-21_17-28-03_b24fe0b8.jpg',
        'https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/14_1aca5972.jpg',
      ],
      icons: [
        { label: 'Culture', icon: <Building2 size={24} /> },
        { label: 'Adventure', icon: <Mountain size={24} /> },
      ],
    },
    {
      name: 'Panjakent',
      description: 'A gateway to adventure featuring ancient ruins, stunning landscapes, and access to the Fann Mountains. Panjakent is perfect for culture and nature enthusiasts.',
      activities: ['Ruin exploration', 'Trekking', 'Photography', 'Local markets'],
      images: [
        'https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/Panjakent-Samarkand-Border-Crossing-5-1024x683-1_66101c08.jpg',
        'https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/photo_2025-04-21_22-41-23_9e3626dc.jpg',
      ],
      icons: [
        { label: 'Culture', icon: <Building2 size={24} /> },
        { label: 'Nature', icon: <Leaf size={24} /> },
      ],
    },
    {
      name: 'Yagnob Valley',
      description: 'An isolated valley preserving ancient Tajik culture and language. Yagnob offers a glimpse into traditional mountain life and stunning natural beauty.',
      activities: ['Cultural immersion', 'Valley trekking', 'Village visits', 'Photography'],
      images: [
        'https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/photo_2025-04-21_22-43-20-2_06dd3226.jpg',
        'https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/photo_2025-04-21_17-44-55_66d79aab.jpg',
      ],
      icons: [
        { label: 'Culture', icon: <Building2 size={24} /> },
        { label: 'Adventure', icon: <Mountain size={24} /> },
      ],
    },
    {
      name: 'Istaravshan',
      description: 'One of Central Asia\'s oldest cities with a fascinating blend of history, architecture, and local culture. Istaravshan showcases the region\'s rich heritage.',
      activities: ['Historical tours', 'Bazaar visits', 'Photography', 'Cultural experiences'],
      images: [
        'https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/Istaravshan-2_56bdfb2b.jpg',
        'https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/IMG_9869-scaled_d8596825.jpg',
      ],
      icons: [
        { label: 'Culture', icon: <Building2 size={24} /> },
        { label: 'Adventure', icon: <Mountain size={24} /> },
      ],
    },
    {
      name: 'Rudaki Mausoleum',
      description: 'A tribute to the great Persian poet and scholar. The mausoleum is an important cultural landmark and a peaceful place of reflection.',
      activities: ['Historical visits', 'Photography', 'Cultural learning', 'Meditation'],
      images: [
        'https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/Hisor-Fortress-featured_image_7f478c5b.jpg',
        'https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/IMG_9869-scaled_d8596825.jpg',
      ],
      icons: [
        { label: 'Culture', icon: <Building2 size={24} /> },
        { label: 'Nature', icon: <Leaf size={24} /> },
      ],
    },
  ],
  south: [
    {
      name: 'Ajina-teppa Buddhist Monastery',
      description: 'An ancient Buddhist site revealing Tajikistan\'s diverse religious heritage. The monastery showcases remarkable archaeological finds and historical significance.',
      activities: ['Archaeological exploration', 'Photography', 'Historical learning', 'Guided tours'],
      images: [
        'https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/14_1aca5972.jpg',
        'https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/photo_2025-04-21_10-55-40_7a4c1508.jpg',
      ],
      icons: [
        { label: 'Culture', icon: <Building2 size={24} /> },
        { label: 'Adventure', icon: <Mountain size={24} /> },
      ],
    },
    {
      name: 'Tahti Sangin Oxus Temple',
      description: 'An important Hellenistic temple complex on the banks of the Oxus River. The site offers insights into ancient trade routes and cultural exchange.',
      activities: ['Archaeological tours', 'River walks', 'Photography', 'Historical study'],
      images: [
        'https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/photo_2025-04-21_17-28-03_b24fe0b8.jpg',
        'https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/Panjakent-Samarkand-Border-Crossing-5-1024x683-1_66101c08.jpg',
      ],
      icons: [
        { label: 'Culture', icon: <Building2 size={24} /> },
        { label: 'Nature', icon: <Leaf size={24} /> },
      ],
    },
    {
      name: 'Chiluchor-Chashma',
      description: 'A picturesque area known for its natural springs and scenic beauty. Perfect for relaxation and nature appreciation in southern Tajikistan.',
      activities: ['Spring bathing', 'Nature walks', 'Photography', 'Picnicking'],
      images: [
        'https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/content_the_health_spa_a23670bf.jpg',
        'https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/photo_2025-04-21_22-43-20-2_06dd3226.jpg',
      ],
      icons: [
        { label: 'Nature', icon: <Leaf size={24} /> },
        { label: 'Adventure', icon: <Mountain size={24} /> },
      ],
    },
    {
      name: 'Khoja Mashad Complex',
      description: 'A spiritual and historical complex featuring ancient structures and sacred sites. The complex reflects the region\'s religious and cultural heritage.',
      activities: ['Spiritual visits', 'Photography', 'Historical tours', 'Cultural immersion'],
      images: [
        'https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/photo_2025-04-21_17-44-55_66d79aab.jpg',
        'https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/Istaravshan-2_56bdfb2b.jpg',
      ],
      icons: [
        { label: 'Culture', icon: <Building2 size={24} /> },
        { label: 'Adventure', icon: <Mountain size={24} /> },
      ],
    },
    {
      name: 'Khoja Mumin Salt Mountain',
      description: 'A unique geological formation with distinctive salt deposits. The mountain offers stunning views and insight into Tajikistan\'s diverse landscapes.',
      activities: ['Geological exploration', 'Photography', 'Hiking', 'Nature study'],
      images: [
        'https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/photo_2025-04-21_22-41-23_9e3626dc.jpg',
        'https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/14_1aca5972.jpg',
      ],
      icons: [
        { label: 'Nature', icon: <Leaf size={24} /> },
        { label: 'Adventure', icon: <Mountain size={24} /> },
      ],
    },
    {
      name: 'Mausoleum Mir Said Ali Khamadoni',
      description: 'A significant Islamic monument honoring a revered spiritual leader. The mausoleum is an important pilgrimage site and cultural landmark.',
      activities: ['Spiritual visits', 'Photography', 'Cultural learning', 'Guided tours'],
      images: [
        'https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/Hisor-Fortress-featured_image_7f478c5b.jpg',
        'https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/photo_2025-04-21_10-55-40_7a4c1508.jpg',
      ],
      icons: [
        { label: 'Culture', icon: <Building2 size={24} /> },
        { label: 'Adventure', icon: <Mountain size={24} /> },
      ],
    },
  ],
  pamir: [
    {
      name: 'Botanical Garden of Pamir',
      description: 'A unique collection of alpine flora showcasing the region\'s botanical diversity. The garden is perfect for nature lovers and photographers.',
      activities: ['Botanical tours', 'Photography', 'Nature walks', 'Educational visits'],
      images: [
        'https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/content_fan_mountain_s_12a3f464.jpg',
        'https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/photo_2025-04-21_17-28-03_b24fe0b8.jpg',
      ],
      icons: [
        { label: 'Nature', icon: <Leaf size={24} /> },
        { label: 'Adventure', icon: <Mountain size={24} /> },
      ],
    },
    {
      name: 'Garm Chashma Hot Spring',
      description: 'Natural thermal springs offering relaxation and wellness in a stunning mountain setting. A perfect retreat for rejuvenation and nature appreciation.',
      activities: ['Hot spring bathing', 'Relaxation', 'Photography', 'Wellness'],
      images: [
        'https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/content_the_health_spa_a23670bf.jpg',
        'https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/Karakul_41_2affee5e.jpg',
      ],
      icons: [
        { label: 'Nature', icon: <Leaf size={24} /> },
        { label: 'Adventure', icon: <Mountain size={24} /> },
      ],
    },
    {
      name: 'Peak Ismoili Somoni',
      description: 'The highest peak in Tajikistan at 7,495 meters. A challenging climb offering unparalleled views and an unforgettable mountaineering experience.',
      activities: ['Mountain climbing', 'Trekking', 'Photography', 'Mountaineering'],
      images: [
        'https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/tajikistan-western-pamir-1-1-1536x864_404dbf5b.jpg',
        'https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/photo_2025-04-21_17-44-55_66d79aab.jpg',
      ],
      icons: [
        { label: 'Adventure', icon: <Mountain size={24} /> },
        { label: 'Nature', icon: <Leaf size={24} /> },
      ],
    },
    {
      name: 'Khorog',
      description: 'A vibrant town in the Wakhan Corridor region. Khorog serves as a gateway to remote Pamir adventures and offers cultural experiences.',
      activities: ['City exploration', 'Bazaar visits', 'Trekking', 'Cultural tours'],
      images: [
        'https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/Khorog-Tajikistan-the-site-of-the-University-of-Central-Asias-second-campus-and-the_3fb80e03.png',
        'https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/photo_2025-04-21_22-41-23_9e3626dc.jpg',
      ],
      icons: [
        { label: 'Adventure', icon: <Mountain size={24} /> },
        { label: 'Culture', icon: <Building2 size={24} /> },
      ],
    },
    {
      name: 'Wakhan Valley',
      description: 'A remote and pristine valley offering isolation, natural beauty, and adventure. Wakhan is ideal for experienced trekkers seeking untouched wilderness.',
      activities: ['Trekking', 'Wildlife observation', 'Photography', 'Camping'],
      images: [
        'https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/photo_2025-04-21_22-43-20-2_06dd3226.jpg',
        'https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/Karakul_41_2affee5e.jpg',
      ],
      icons: [
        { label: 'Adventure', icon: <Mountain size={24} /> },
        { label: 'Nature', icon: <Leaf size={24} /> },
      ],
    },
    {
      name: 'Pamir Petroglyphs & Karakul Lake',
      description: 'Ancient rock art and a stunning high-altitude lake. This area combines historical significance with breathtaking natural beauty.',
      images: [
        'https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/Karakul_41_2affee5e.jpg',
        'https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/tajikistan-western-pamir-1-1-1536x864_404dbf5b.jpg',
      ],
      activities: ['Archaeological exploration', 'Lake visits', 'Photography', 'Hiking'],
      icons: [
        { label: 'Culture', icon: <Building2 size={24} /> },
        { label: 'Nature', icon: <Leaf size={24} /> },
      ],
    },
    {
      name: 'Yamchun and Kahkaha Fortress',
      description: 'Historic fortresses showcasing strategic mountain positions and ancient architecture. These sites offer insights into the region\'s military and cultural history.',
      activities: ['Historical tours', 'Photography', 'Hiking', 'Archaeological study'],
      images: [
        'https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/Hisor-Fortress-featured_image_7f478c5b.jpg',
        'https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/photo_2025-04-21_17-44-55_66d79aab.jpg',
      ],
      icons: [
        { label: 'Culture', icon: <Building2 size={24} /> },
        { label: 'Adventure', icon: <Mountain size={24} /> },
      ],
    },
  ],
};

function DestinationCard({ destination }: { destination: Destination }) {
  return (
    <div className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-all duration-300">
      <Carousel images={destination.images} autoPlay={true} autoPlayInterval={5000} height="h-64" showControls={true} />
      <div className="p-6">
        <h3 className="text-2xl font-bold text-foreground mb-2" style={{ fontFamily: 'var(--font-serif-display)' }}>
          {destination.name}
        </h3>
        <p className="text-muted-foreground mb-4" style={{ fontFamily: 'var(--font-serif-body)' }}>
          {destination.description}
        </p>

        {/* Activity Icons */}
        <div className="flex gap-4 mb-4">
          {destination.icons.map((item, idx) => (
            <div key={idx} className="flex items-center gap-2 text-primary">
              {item.icon}
              <span className="text-sm font-medium">{item.label}</span>
            </div>
          ))}
        </div>

        {/* Activities List */}
        <div className="mb-4">
          <p className="text-sm font-semibold text-foreground mb-2">Best Activities:</p>
          <div className="flex flex-wrap gap-2">
            {destination.activities.map((activity, idx) => (
              <span key={idx} className="px-3 py-1 bg-primary/10 text-primary rounded-full text-sm font-medium">
                {activity}
              </span>
            ))}
          </div>
        </div>

        {/* WhatsApp Button */}
        <a
          href="https://wa.link/ilvyha"
          target="_blank"
          rel="noopener noreferrer"
          className="w-full px-4 py-2 bg-primary text-foreground rounded-lg font-bold hover:bg-secondary transition-all duration-300 text-center"
        >
          Book via WhatsApp
        </a>
      </div>
    </div>
  );
}

export default function Destinations() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      {/* Hero Section */}
      <section className="pt-32 pb-12 bg-muted border-b border-border">
        <div className="container text-center">
          <h1 className="text-5xl sm:text-6xl font-bold text-foreground mb-4" style={{ fontFamily: 'var(--font-serif-display)' }}>
            Explore Tajikistan
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto" style={{ fontFamily: 'var(--font-serif-body)' }}>
            Discover the diverse regions of Tajikistan, from northern mountains to southern deserts and the remote Pamir plateau
          </p>
        </div>
      </section>

      {/* Northern Tajikistan */}
      <section className="py-16 bg-background">
        <div className="container">
          <div className="flex items-center gap-4 mb-12">
            <MapPin className="text-primary" size={32} />
            <h2 className="text-4xl font-bold text-foreground" style={{ fontFamily: 'var(--font-serif-display)' }}>
              Northern Tajikistan
            </h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {destinations.north.map((dest, idx) => (
              <DestinationCard key={idx} destination={dest} />
            ))}
          </div>
        </div>
      </section>

      {/* Southern Tajikistan */}
      <section className="py-16 bg-muted">
        <div className="container">
          <div className="flex items-center gap-4 mb-12">
            <MapPin className="text-primary" size={32} />
            <h2 className="text-4xl font-bold text-foreground" style={{ fontFamily: 'var(--font-serif-display)' }}>
              Southern Tajikistan
            </h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {destinations.south.map((dest, idx) => (
              <DestinationCard key={idx} destination={dest} />
            ))}
          </div>
        </div>
      </section>

      {/* Pamir Region */}
      <section className="py-16 bg-background">
        <div className="container">
          <div className="flex items-center gap-4 mb-12">
            <MapPin className="text-primary" size={32} />
            <h2 className="text-4xl font-bold text-foreground" style={{ fontFamily: 'var(--font-serif-display)' }}>
              Pamir Region
            </h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {destinations.pamir.map((dest, idx) => (
              <DestinationCard key={idx} destination={dest} />
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-primary/5 border-t border-border">
        <div className="container text-center">
          <h2 className="text-4xl font-bold text-foreground mb-6" style={{ fontFamily: 'var(--font-serif-display)' }}>
            Ready to Plan Your Journey?
          </h2>
          <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto" style={{ fontFamily: 'var(--font-serif-body)' }}>
            Contact us to customize your tour and create unforgettable memories in Tajikistan
          </p>
          <a
            href="https://wa.link/ilvyha"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-8 py-4 bg-primary text-foreground rounded-lg font-bold text-lg hover:bg-secondary transition-all duration-300 hover:shadow-lg hover:scale-105"
          >
            Start Planning
          </a>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-foreground text-background py-12">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="text-lg font-bold mb-4">Pamir Alichur Tours</h4>
              <p className="text-background/80">Premium travel experiences in Tajikistan's most spectacular regions</p>
            </div>
            <div>
              <h4 className="text-lg font-bold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-background/80">
                <li><a href="/" className="hover:text-background transition-colors">Home</a></li>
                <li><a href="/destinations" className="hover:text-background transition-colors">Destinations</a></li>
                <li><a href="/gallery" className="hover:text-background transition-colors">Gallery</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-bold mb-4">Contact</h4>
              <ul className="space-y-2 text-background/80">
                <li>📞 +992 003115403</li>
                <li>📧 pamiralichurtours@gmail.com</li>
                <li><a href="https://wa.link/ilvyha" target="_blank" rel="noopener noreferrer" className="hover:text-background transition-colors">💬 WhatsApp</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-bold mb-4">Follow Us</h4>
              <ul className="space-y-2 text-background/80">
                <li><a href="https://www.instagram.com/pamir_alichur_tours/" target="_blank" rel="noopener noreferrer" className="hover:text-background transition-colors">📸 Instagram</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-background/20 pt-8 text-center text-background/70">
            <p>&copy; {new Date().getFullYear()} Pamir Alichur Tours. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
