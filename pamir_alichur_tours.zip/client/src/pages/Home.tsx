import { Link } from 'wouter';
import { ArrowRight, Mountain, Camera, Compass } from 'lucide-react';
import Navigation from '@/components/Navigation';
import Carousel from '@/components/Carousel';
import { useEffect, useState } from 'react';

export default function Home() {
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    setIsLoaded(true);
  }, []);

  const galleryImages = [
    'https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/content_fan_mountain_s_12a3f464.jpg',
    'https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/Karakul_41_2affee5e.jpg',
    'https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/tajikistan-western-pamir-1-1-1536x864_404dbf5b.jpg',
    'https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/photo_2025-04-21_17-44-55_66d79aab.jpg',
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      {/* Hero Section */}
      <section className="relative w-full h-screen pt-16 overflow-hidden cinematic-hero">
        {/* Background Image with Parallax */}
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: `url('https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/Karakul_41_2affee5e.jpg')`,
            backgroundAttachment: 'fixed',
            backgroundPosition: 'center',
          }}
        />

        {/* Fog Overlay */}
        <div className="fog-overlay" />

        {/* Vignette */}
        <div className="vignette" />

        {/* Content */}
        <div className="relative z-10 h-full flex flex-col items-center justify-center text-center px-4 sm:px-6 lg:px-8">
          <div className={`transform transition-all duration-1200 ${isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
            <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold text-white mb-6 drop-shadow-lg" style={{ fontFamily: 'var(--font-serif-display)' }}>
              Discover Tajikistan's
              <br />
              <span className="text-primary">Hidden Treasures</span>
            </h1>
          </div>

          <div className={`transform transition-all duration-1200 delay-300 ${isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
            <p className="text-lg sm:text-xl text-white/90 mb-12 max-w-2xl drop-shadow-md" style={{ fontFamily: 'var(--font-serif-body)' }}>
              Experience the majesty of Pamir mountains, ancient cultural heritage, and pristine desert landscapes
            </p>
          </div>

          {/* CTA Buttons */}
          <div className={`flex flex-col sm:flex-row gap-6 transform transition-all duration-1200 delay-500 ${isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
            <Link href="/destinations">
              <a className="px-8 py-4 bg-primary text-foreground rounded-lg font-bold text-lg hover:bg-secondary transition-all duration-300 hover:shadow-lg hover:scale-105 inline-flex items-center gap-2">
                Explore Destinations
                <ArrowRight size={20} />
              </a>
            </Link>
            <Link href="/gallery">
              <a className="px-8 py-4 bg-white/20 backdrop-blur-sm text-white rounded-lg font-bold text-lg hover:bg-white/30 transition-all duration-300 hover:shadow-lg hover:scale-105 inline-flex items-center gap-2 border border-white/30">
                View Gallery
                <Camera size={20} />
              </a>
            </Link>
          </div>
        </div>

        {/* Scroll Indicator */}
        <div className={`absolute bottom-8 left-1/2 -translate-x-1/2 z-10 transform transition-all duration-1200 delay-700 ${isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          <div className="flex flex-col items-center gap-2 animate-bounce">
            <span className="text-white/70 text-sm">Scroll to explore</span>
            <svg className="w-6 h-6 text-white/70" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
            </svg>
          </div>
        </div>
      </section>

      {/* Featured Carousel Section */}
      <section className="py-20 bg-background">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-4xl sm:text-5xl font-bold text-foreground mb-4" style={{ fontFamily: 'var(--font-serif-display)' }}>
              Journey Through Pamir
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto" style={{ fontFamily: 'var(--font-serif-body)' }}>
              Witness the breathtaking landscapes that define Central Asia's most magnificent region
            </p>
          </div>
          <Carousel images={galleryImages} autoPlayInterval={6000} height="h-96 sm:h-[500px]" />
        </div>
      </section>

      {/* Highlights Section */}
      <section className="py-20 bg-muted">
        <div className="container">
          <h2 className="text-4xl font-bold text-foreground mb-12 text-center" style={{ fontFamily: 'var(--font-serif-display)' }}>
            Why Choose Pamir Alichur Tours
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Highlight 1 */}
            <div className="bg-white rounded-lg p-8 hover:shadow-lg transition-all duration-300 hover:scale-105">
              <div className="flex items-center justify-center w-16 h-16 bg-primary/10 rounded-full mb-6">
                <Mountain className="text-primary" size={32} />
              </div>
              <h3 className="text-2xl font-bold text-foreground mb-4" style={{ fontFamily: 'var(--font-serif-display)' }}>
                Mountain Adventures
              </h3>
              <p className="text-muted-foreground" style={{ fontFamily: 'var(--font-serif-body)' }}>
                Explore the majestic peaks of Pamir, including Peak Ismoili Somoni and pristine alpine lakes
              </p>
            </div>

            {/* Highlight 2 */}
            <div className="bg-white rounded-lg p-8 hover:shadow-lg transition-all duration-300 hover:scale-105">
              <div className="flex items-center justify-center w-16 h-16 bg-primary/10 rounded-full mb-6">
                <Compass className="text-primary" size={32} />
              </div>
              <h3 className="text-2xl font-bold text-foreground mb-4" style={{ fontFamily: 'var(--font-serif-display)' }}>
                Cultural Heritage
              </h3>
              <p className="text-muted-foreground" style={{ fontFamily: 'var(--font-serif-body)' }}>
                Discover ancient temples, fortresses, and the rich traditions of Tajikistan's diverse communities
              </p>
            </div>

            {/* Highlight 3 */}
            <div className="bg-white rounded-lg p-8 hover:shadow-lg transition-all duration-300 hover:scale-105">
              <div className="flex items-center justify-center w-16 h-16 bg-primary/10 rounded-full mb-6">
                <Camera className="text-primary" size={32} />
              </div>
              <h3 className="text-2xl font-bold text-foreground mb-4" style={{ fontFamily: 'var(--font-serif-display)' }}>
                Stunning Landscapes
              </h3>
              <p className="text-muted-foreground" style={{ fontFamily: 'var(--font-serif-body)' }}>
                Capture unforgettable moments in deserts, valleys, and mountain vistas of unparalleled beauty
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-primary/5 border-t border-border">
        <div className="container text-center">
          <h2 className="text-4xl font-bold text-foreground mb-6" style={{ fontFamily: 'var(--font-serif-display)' }}>
            Ready to Start Your Adventure?
          </h2>
          <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto" style={{ fontFamily: 'var(--font-serif-body)' }}>
            Contact us via WhatsApp to book your custom tour and experience the magic of Tajikistan
          </p>
          <a
            href="https://wa.link/ilvyha"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-8 py-4 bg-primary text-foreground rounded-lg font-bold text-lg hover:bg-secondary transition-all duration-300 hover:shadow-lg hover:scale-105"
          >
            Book via WhatsApp
            <ArrowRight size={20} />
          </a>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-foreground text-background py-12">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="text-lg font-bold mb-4">Pamir Alichur Tours</h4>
              <p className="text-background/80">Premium travel experiences in Tajikistan's most spectacular regions</p>
            </div>
            <div>
              <h4 className="text-lg font-bold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-background/80">
                <li><Link href="/"><a className="hover:text-background transition-colors">Home</a></Link></li>
                <li><Link href="/destinations"><a className="hover:text-background transition-colors">Destinations</a></Link></li>
                <li><Link href="/gallery"><a className="hover:text-background transition-colors">Gallery</a></Link></li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-bold mb-4">Contact</h4>
              <ul className="space-y-2 text-background/80">
                <li>📞 +992 003115403</li>
                <li>📧 pamiralichurtours@gmail.com</li>
                <li><a href="https://wa.link/ilvyha" target="_blank" rel="noopener noreferrer" className="hover:text-background transition-colors">💬 WhatsApp</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-bold mb-4">Follow Us</h4>
              <ul className="space-y-2 text-background/80">
                <li><a href="https://www.instagram.com/pamir_alichur_tours/" target="_blank" rel="noopener noreferrer" className="hover:text-background transition-colors">📸 Instagram</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-background/20 pt-8 text-center text-background/70">
            <p>&copy; {new Date().getFullYear()} Pamir Alichur Tours. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
