import Navigation from '@/components/Navigation';
import Carousel from '@/components/Carousel';
import { useState } from 'react';
import { X } from 'lucide-react';

interface GalleryCategory {
  name: string;
  description: string;
  images: string[];
}

const galleryCategories: GalleryCategory[] = [
  {
    name: 'Mountains',
    description: 'Majestic peaks and alpine landscapes of Tajikistan',
    images: [
      'https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/content_fan_mountain_s_12a3f464.jpg',
      'https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/tajikistan-western-pamir-1-1-1536x864_404dbf5b.jpg',
      'https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/photo_2025-04-21_17-44-55_66d79aab.jpg',
      'https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/photo_2025-04-21_22-43-20-2_06dd3226.jpg',
    ],
  },
  {
    name: 'Culture & Heritage',
    description: 'Ancient sites, fortresses, and cultural landmarks',
    images: [
      'https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/Hisor-Fortress-featured_image_7f478c5b.jpg',
      'https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/Istaravshan-2_56bdfb2b.jpg',
      'https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/IMG_9869-scaled_d8596825.jpg',
      'https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/Panjakent-Samarkand-Border-Crossing-5-1024x683-1_66101c08.jpg',
    ],
  },
  {
    name: 'Desert & Lakes',
    description: 'Pristine alpine lakes and desert landscapes',
    images: [
      'https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/Karakul_41_2affee5e.jpg',
      'https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/photo_2025-04-21_10-55-40_7a4c1508.jpg',
      'https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/photo_2025-04-21_17-28-03_b24fe0b8.jpg',
      'https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/photo_2025-04-21_22-41-23_9e3626dc.jpg',
    ],
  },
  {
    name: 'Nature & Wellness',
    description: 'Hot springs, botanical gardens, and natural wonders',
    images: [
      'https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/content_the_health_spa_a23670bf.jpg',
      'https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/14_1aca5972.jpg',
      'https://d2xsxph8kpxj0f.cloudfront.net/310519663471392161/YqxnxzqQcz4XNpCcurRdQx/Khorog-Tajikistan-the-site-of-the-University-of-Central-Asias-second-campus-and-the_3fb80e03.png',
    ],
  },
];

interface LightboxImage {
  url: string;
  category: string;
}

export default function Gallery() {
  const [selectedImage, setSelectedImage] = useState<LightboxImage | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  // Get all images for main carousel
  const allImages = galleryCategories.flatMap(cat => cat.images);

  // Get images for category carousel
  const categoryImages = selectedCategory
    ? galleryCategories.find(cat => cat.name === selectedCategory)?.images || []
    : [];

  const handlePrevImage = () => {
    if (!selectedImage) return;
    const currentIndex = allImages.indexOf(selectedImage.url);
    const prevIndex = (currentIndex - 1 + allImages.length) % allImages.length;
    setSelectedImage({ url: allImages[prevIndex], category: selectedImage.category });
  };

  const handleNextImage = () => {
    if (!selectedImage) return;
    const currentIndex = allImages.indexOf(selectedImage.url);
    const nextIndex = (currentIndex + 1) % allImages.length;
    setSelectedImage({ url: allImages[nextIndex], category: selectedImage.category });
  };

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      {/* Hero Section */}
      <section className="pt-32 pb-12 bg-muted border-b border-border">
        <div className="container text-center">
          <h1 className="text-5xl sm:text-6xl font-bold text-foreground mb-4" style={{ fontFamily: 'var(--font-serif-display)' }}>
            Gallery
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto" style={{ fontFamily: 'var(--font-serif-body)' }}>
            Immerse yourself in the visual beauty of Tajikistan's mountains, deserts, and cultural heritage
          </p>
        </div>
      </section>

      {/* Main Carousel */}
      <section className="py-16 bg-background">
        <div className="container">
          <h2 className="text-3xl font-bold text-foreground mb-8 text-center" style={{ fontFamily: 'var(--font-serif-display)' }}>
            Featured Collection
          </h2>
          <Carousel images={allImages} autoPlayInterval={6000} height="h-96 sm:h-[600px]" />
          <p className="text-center text-muted-foreground mt-4" style={{ fontFamily: 'var(--font-serif-body)' }}>
            Click on any image below to explore by category
          </p>
        </div>
      </section>

      {/* Category Buttons */}
      <section className="py-12 bg-muted">
        <div className="container">
          <div className="flex flex-wrap justify-center gap-4">
            {galleryCategories.map((category) => (
              <button
                key={category.name}
                onClick={() => setSelectedCategory(selectedCategory === category.name ? null : category.name)}
                className={`px-6 py-3 rounded-lg font-bold transition-all duration-300 ${
                  selectedCategory === category.name
                    ? 'bg-primary text-foreground shadow-lg scale-105'
                    : 'bg-white text-foreground hover:bg-primary/10 border border-primary/20'
                }`}
              >
                {category.name}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Category View */}
      {selectedCategory && (
        <section className="py-16 bg-background">
          <div className="container">
            {galleryCategories.map((category) => {
              if (category.name !== selectedCategory) return null;
              return (
                <div key={category.name}>
                  <div className="mb-8">
                    <h2 className="text-4xl font-bold text-foreground mb-2" style={{ fontFamily: 'var(--font-serif-display)' }}>
                      {category.name}
                    </h2>
                    <p className="text-lg text-muted-foreground" style={{ fontFamily: 'var(--font-serif-body)' }}>
                      {category.description}
                    </p>
                  </div>
                  <Carousel images={category.images} autoPlayInterval={5000} height="h-96 sm:h-[500px]" />
                </div>
              );
            })}
          </div>
        </section>
      )}

      {/* Image Grid */}
      <section className="py-16 bg-muted">
        <div className="container">
          <h2 className="text-3xl font-bold text-foreground mb-8 text-center" style={{ fontFamily: 'var(--font-serif-display)' }}>
            Browse All Images
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {allImages.map((image, idx) => (
              <div
                key={idx}
                onClick={() => setSelectedImage({ url: image, category: 'All' })}
                className="relative h-64 rounded-lg overflow-hidden cursor-pointer group hover:shadow-lg transition-all duration-300"
              >
                <img
                  src={image}
                  alt={`Gallery image ${idx + 1}`}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors duration-300" />
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="bg-white/90 rounded-full p-3">
                    <svg className="w-6 h-6 text-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM10 7v6m3-3H7" />
                    </svg>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Lightbox Modal */}
      {selectedImage && (
        <div className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-4">
          <div className="relative w-full max-w-4xl">
            {/* Close Button */}
            <button
              onClick={() => setSelectedImage(null)}
              className="absolute -top-12 right-0 text-white hover:text-primary transition-colors"
            >
              <X size={32} />
            </button>

            {/* Image */}
            <div className="relative bg-black rounded-lg overflow-hidden">
              <img
                src={selectedImage.url}
                alt="Full size"
                className="w-full h-auto max-h-[80vh] object-contain"
              />

              {/* Navigation Buttons */}
              <button
                onClick={handlePrevImage}
                className="absolute left-4 top-1/2 -translate-y-1/2 bg-white/20 hover:bg-white/40 text-white p-3 rounded-full transition-all duration-300"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
              </button>
              <button
                onClick={handleNextImage}
                className="absolute right-4 top-1/2 -translate-y-1/2 bg-white/20 hover:bg-white/40 text-white p-3 rounded-full transition-all duration-300"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </button>

              {/* Image Counter */}
              <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-black/60 text-white px-4 py-2 rounded-full">
                {allImages.indexOf(selectedImage.url) + 1} / {allImages.length}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* CTA Section */}
      <section className="py-20 bg-primary/5 border-t border-border">
        <div className="container text-center">
          <h2 className="text-4xl font-bold text-foreground mb-6" style={{ fontFamily: 'var(--font-serif-display)' }}>
            Inspired by These Views?
          </h2>
          <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto" style={{ fontFamily: 'var(--font-serif-body)' }}>
            Book your adventure today and create your own unforgettable moments in Tajikistan
          </p>
          <a
            href="https://wa.link/ilvyha"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-8 py-4 bg-primary text-foreground rounded-lg font-bold text-lg hover:bg-secondary transition-all duration-300 hover:shadow-lg hover:scale-105"
          >
            Start Your Journey
          </a>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-foreground text-background py-12">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="text-lg font-bold mb-4">Pamir Alichur Tours</h4>
              <p className="text-background/80">Premium travel experiences in Tajikistan's most spectacular regions</p>
            </div>
            <div>
              <h4 className="text-lg font-bold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-background/80">
                <li><a href="/" className="hover:text-background transition-colors">Home</a></li>
                <li><a href="/destinations" className="hover:text-background transition-colors">Destinations</a></li>
                <li><a href="/gallery" className="hover:text-background transition-colors">Gallery</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-bold mb-4">Contact</h4>
              <ul className="space-y-2 text-background/80">
                <li>📞 +992 003115403</li>
                <li>📧 pamiralichurtours@gmail.com</li>
                <li><a href="https://wa.link/ilvyha" target="_blank" rel="noopener noreferrer" className="hover:text-background transition-colors">💬 WhatsApp</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-bold mb-4">Follow Us</h4>
              <ul className="space-y-2 text-background/80">
                <li><a href="https://www.instagram.com/pamir_alichur_tours/" target="_blank" rel="noopener noreferrer" className="hover:text-background transition-colors">📸 Instagram</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-background/20 pt-8 text-center text-background/70">
            <p>&copy; {new Date().getFullYear()} Pamir Alichur Tours. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
