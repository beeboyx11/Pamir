import { Link } from 'wouter';
import { Menu, X } from 'lucide-react';
import { useState } from 'react';

export default function Navigation() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border">
      <div className="container flex items-center justify-between h-16">
        {/* Logo */}
        <Link href="/">
          <a className="flex items-center gap-2 group">
            <div className="text-2xl font-bold text-primary">🏔️</div>
            <span className="text-lg font-bold text-foreground group-hover:text-primary transition-colors">
              Pamir Alichur
            </span>
          </a>
        </Link>

        {/* Desktop Menu */}
        <div className="hidden md:flex items-center gap-8">
          <Link href="/">
            <a className="text-foreground hover:text-primary transition-colors font-medium">
              Home
            </a>
          </Link>
          <Link href="/destinations">
            <a className="text-foreground hover:text-primary transition-colors font-medium">
              Destinations
            </a>
          </Link>
          <Link href="/gallery">
            <a className="text-foreground hover:text-primary transition-colors font-medium">
              Gallery
            </a>
          </Link>
          <a
            href="https://wa.link/ilvyha"
            target="_blank"
            rel="noopener noreferrer"
            className="px-6 py-2 bg-primary text-foreground rounded-lg hover:bg-secondary transition-all duration-300 font-medium"
          >
            Contact
          </a>
        </div>

        {/* Mobile Menu Button */}
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="md:hidden p-2 hover:bg-muted rounded-lg transition-colors"
        >
          {isOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden border-t border-border bg-background">
          <div className="container py-4 flex flex-col gap-4">
            <Link href="/">
              <a
                onClick={() => setIsOpen(false)}
                className="text-foreground hover:text-primary transition-colors font-medium"
              >
                Home
              </a>
            </Link>
            <Link href="/destinations">
              <a
                onClick={() => setIsOpen(false)}
                className="text-foreground hover:text-primary transition-colors font-medium"
              >
                Destinations
              </a>
            </Link>
            <Link href="/gallery">
              <a
                onClick={() => setIsOpen(false)}
                className="text-foreground hover:text-primary transition-colors font-medium"
              >
                Gallery
              </a>
            </Link>
            <a
              href="https://wa.link/ilvyha"
              target="_blank"
              rel="noopener noreferrer"
              className="px-6 py-2 bg-primary text-foreground rounded-lg hover:bg-secondary transition-all duration-300 font-medium text-center"
            >
              Contact
            </a>
          </div>
        </div>
      )}
    </nav>
  );
}
